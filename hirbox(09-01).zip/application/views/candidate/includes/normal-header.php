
    <header id="page-topbar" style="background-color: #ffffff;border-color: #ffffff;">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box" style="background-color: #ffffff;border-color: #ffffff;">
                <a href="<?= base_url('company') ?>" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?= base_url() ?>assets/images/logo.png" alt="" height="30">
                    </span>
                    <span class="logo-lg">
                        <img src="<?= base_url() ?>assets/images/logo.png" alt="" height="34">
                    </span>
                </a>

                <a href="<?= base_url('company') ?>" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?= base_url() ?>assets/images/logo.png" alt="" height="30">
                    </span>
                    <span class="logo-lg">
                        <img src="<?= base_url() ?>assets/images/logo.png" alt="" height="34">
                    </span>
                </a>
            </div>



        </div>


    </div>
</header>