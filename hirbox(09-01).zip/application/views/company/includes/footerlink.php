<script src="<?= base_url() ?>assets/libs/jquery/jquery.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/node-waves/waves.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/feather-icons/feather.min.js"></script>
        <!-- pace js -->
        <script src="<?= base_url() ?>assets/libs/pace-js/pace.min.js"></script>

        <!-- apexcharts -->
        <script src="<?= base_url() ?>assets/libs/apexcharts/apexcharts.min.js"></script>

        <!-- Plugins js-->
        <script src="<?= base_url() ?>assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>
        <!-- dashboard init -->
        <script src="<?= base_url() ?>assets/js/pages/dashboard.init.js"></script>

        <script src="<?= base_url() ?>assets/js/app.js"></script>


        <!-- select 2 plugin -->
        <script src="<?= base_url() ?>assets/libs/select2/js/select2.min.js"></script>

        <!-- dropzone plugin -->
        <script src="<?= base_url() ?>assets/libs/dropzone/min/dropzone.min.js"></script>



          
        

        <!-- Required datatable js -->
        <script src="<?= base_url() ?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?= base_url() ?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/jszip/jszip.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="<?= base_url() ?>assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>

        <!-- Responsive examples -->
        <script src="<?= base_url() ?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?= base_url() ?>assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
        <script src="<?= base_url() ?>assets/js/pages/datatables.init.js"></script> 
        
        
         <!-- ckeditor -->
         <script src="assets/libs/%40ckeditor/ckeditor5-build-classic/build/ckeditor.js"></script>

         <!-- init js -->
        <script src="assets/js/pages/form-editor.init.js"></script>

        