<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Dason.
                            </div> -->
                            <div class="col-sm-12">
                                <div class="text-sm-end d-none d-sm-block">
                                Copyright © <script>document.write(new Date().getFullYear())</script> Hirbox | Powered by Hirbox
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>